
package com.mycompany.consolesalesapplication;

public abstract class Console implements IConsoles {
    
    private String consoleType;
    private String store;
    private int totalSales;

    // Constructor
    public Console(String consoleType, String store, int totalSales) {
        this.consoleType = consoleType;
        this.store = store;
        this.totalSales = totalSales;
    }

    // Getter for console type
    @Override
    public String getConsoleType() {
        return consoleType;
    }

    // Getter for store
    @Override
    public String getStore() {
        return store;
    }

    // Getter for total sales
    @Override
    public int getTotalSales() {
        return totalSales;
    }
}


    

