
package com.mycompany.consolesalesapplication;

public interface IConsoles {
    
    String getConsoleType();

    String getStore();

    int getTotalSales();

}
