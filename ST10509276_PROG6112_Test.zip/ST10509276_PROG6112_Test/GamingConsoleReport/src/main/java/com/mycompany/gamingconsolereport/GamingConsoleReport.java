/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gamingconsolereport;

/**
 *
 * @author Student
 */
public class GamingConsoleReport {

    public static void main(String[] args) {
       // Single-dimensional arrays: row labels (cities) and column labels (consoles)
        String[] cities = {"CAPE TOWN", "PORT ELIZABETH", "PRETORIA"};
        String[] consoles = {"PSS", "XBOX", "SWITCH"};

        // Two-dimensional array: rows = cities, columns = consoles
        int[][] sales = {
            {1000, 2000, 3000},   // Cape Town
            {2000, 3000, 4000},   // Port Elizabeth
            {1500, 1100, 1200}    // Pretoria
        };

        // Single-dimensional array to hold the total sales for each city
        int[] cityTotals = new int[cities.length];

        // Calculate totals per city
        for (int row = 0; row < sales.length; row++) {
            for (int col = 0; col < sales[row].length; col++) {
                cityTotals[row] += sales[row][col];
            }
        }

        // Find the city with the most sales
        int highestIndex = 0;
        for (int i = 1; i < cityTotals.length; i++) {
            if (cityTotals[i] > cityTotals[highestIndex]) {
                highestIndex = i;
            }
        }

        String line = "--------------------------------------------------";

        // Report: sales per city and console
        System.out.println(line);
        System.out.println("GAMING CONSOLE REPORT");
        System.out.println(line);

        System.out.printf("%-16s", "");
        for (String console : consoles) {
            System.out.printf("%-8s", console);
        }
        System.out.println();

        for (int row = 0; row < cities.length; row++) {
            System.out.printf("%-16s", cities[row]);
            for (int col = 0; col < consoles.length; col++) {
                System.out.printf("%-8d", sales[row][col]);
            }
            System.out.println();
        }

        // Report: totals per city
        System.out.println(line);
        System.out.println("CONSOLE SALES TOTALS FOR EACH CITY");
        System.out.println(line);
        for (int i = 0; i < cities.length; i++) {
            System.out.printf("%-16s%d%n", cities[i], cityTotals[i]);
        }

        // Report: city with the most sales
        System.out.println(line);
        System.out.println("CITY WITH THE MOST SALES: " + cities[highestIndex]);
        System.out.println(line);
    }
}
